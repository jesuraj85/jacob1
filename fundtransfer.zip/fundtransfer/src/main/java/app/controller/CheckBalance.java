package app.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/checkbalance")
public class CheckBalance {

	@RequestMapping(method = RequestMethod.GET, value = "/{accountno}")
	public String checkbalance(@PathVariable("accountno") String accountno) {

		return "{\"name\":\"Raju\", \"balance\": \"10000\"}";
	}

}
