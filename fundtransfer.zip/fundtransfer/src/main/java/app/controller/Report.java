package app.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/report")
public class Report {

	@RequestMapping(method = RequestMethod.GET, value = "/{accountno}")
	public String report(@PathVariable("accountno") String accountno) {
		return "{\"name\":\"Raju\", \"accountno\": \"998654\",\"statement\": \"08/01-EBBILL-2200,08/02-ATM_WITHDRAW-1200,08/01-RETAIL-1000,\"}";
	}

}
