package app.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/fundtransfer")
public class TransferFund {

	@RequestMapping(method = RequestMethod.GET, value = "/{accountno}")
	public String transfer(@PathVariable("accountno") String accountno) {
		return "{\"status\":\"completed\", \"desc\": \"Transferred\",\"amount\": \"1000\"}";
	}

}
