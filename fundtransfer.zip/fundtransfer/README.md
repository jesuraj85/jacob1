# springboot-rest-api-demo
Sample showing REST API implementation using Spring Boot and MongoDB as the backend
