// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---web-pages-404-tsx": preferDefault(require("/Users/rodrigo/Trabajo/Chatito/web/pages/404.tsx")),
  "component---web-pages-index-tsx": preferDefault(require("/Users/rodrigo/Trabajo/Chatito/web/pages/index.tsx"))
}

