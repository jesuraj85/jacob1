// prefer default export if available
const preferDefault = m => m && m.default || m

exports.components = {
  "component---web-pages-404-tsx": () => import("/Users/rodrigo/Trabajo/Chatito/web/pages/404.tsx" /* webpackChunkName: "component---web-pages-404-tsx" */),
  "component---web-pages-index-tsx": () => import("/Users/rodrigo/Trabajo/Chatito/web/pages/index.tsx" /* webpackChunkName: "component---web-pages-index-tsx" */)
}

exports.data = () => import("/Users/rodrigo/Trabajo/Chatito/.cache/data.json")

